$(document).ready(function () {
    var gauge;
    var gaugeUpdateInterval;

    $('#startBtn').click(function () {
        $('#startView').hide();
        $('#resultView').show();
        $('#restartBtn').hide();
        performSpeedTest();
    });

    $('#restartBtn').click(function () {
        resetView();
    });

    // Thêm sự kiện cho nút Xóa Lịch Sử
    $('#clearHistoryBtn').click(function () {
        if (confirm('Bạn có chắc chắn muốn xóa toàn bộ lịch sử?')) {
            clearHistory();
        }
    });

    function performSpeedTest() {
        console.log("Starting speed test...");

        fetch('/speedtest')
            .then(response => response.json())
            .then(data => {
                console.log("Speed test data:", data);
                $('#pingValue').text(data.ping.toFixed(2));
                $('#packetLossValue').text(data.packetLoss.toFixed(2));

                initializeGauge();

                let maxDownloadSpeed = data.downloadSpeed; // Maximum download speed
                let maxUploadSpeed = data.uploadSpeed; // Maximum upload speed
                let intervalDuration = 100; // Update every 100ms
                let downloadTime = 8000; // 8 seconds for download
                let uploadTime = 8000; // 8 seconds for upload

                startDownloadTest(maxDownloadSpeed, downloadTime, intervalDuration, function () {
                    startUploadTest(maxUploadSpeed, uploadTime, intervalDuration);
                });
            })
            .catch(error => {
                console.error('Error during speed test:', error);
                alert('An error occurred while performing the speed test. Please try again.');
                resetView();
            });
    }

    function clearHistory() {
        fetch('/speedtest/history/clear', { method: 'DELETE' })
            .then(response => {
                if (response.ok) {
                    alert('Lịch sử đã được xóa.');
                    resetView(); // Sau khi xóa lịch sử thì reset giao diện
                } else {
                    alert('Có lỗi xảy ra khi xóa lịch sử.');
                }
            })
            .catch(error => {
                console.error('Error clearing history:', error);
                alert('Có lỗi xảy ra khi xóa lịch sử.');
            });
    }

    function startDownloadTest(maxSpeed, totalTime, intervalDuration, callback) {
        let startTime = Date.now();

        gaugeUpdateInterval = setInterval(() => {
            let elapsedTime = Date.now() - startTime;
            if (elapsedTime < totalTime) {
                let downloadSpeed = Math.min(maxSpeed, (elapsedTime / totalTime) * maxSpeed);
                gauge.set(downloadSpeed);
                $('#speedValue').text(downloadSpeed.toFixed(2));
                $('#downloadValue').text(downloadSpeed.toFixed(2));
            } else {
                clearInterval(gaugeUpdateInterval);
                $('#downloadValue').text(maxSpeed.toFixed(2));
                callback();
            }
        }, intervalDuration);
    }

    function startUploadTest(maxSpeed, totalTime, intervalDuration) {
        $('#speedValue').text('0');
        $('#uploadValue').text('0');
        let startTime = Date.now();

        gaugeUpdateInterval = setInterval(() => {
            let elapsedTime = Date.now() - startTime;
            if (elapsedTime < totalTime) {
                let uploadSpeed = Math.min(maxSpeed, (elapsedTime / totalTime) * maxSpeed);
                gauge.set(uploadSpeed);
                $('#speedValue').text(uploadSpeed.toFixed(2));
                $('#uploadValue').text(uploadSpeed.toFixed(2));
            } else {
                clearInterval(gaugeUpdateInterval);
                $('#uploadValue').text(maxSpeed.toFixed(2));
                $('#restartBtn').show();
            }
        }, intervalDuration);
    }

    function initializeGauge() {
        let options = {
            angle: 0, // The span of the gauge arc
            lineWidth: 0.3, // The line thickness
            radiusScale: 1, // Relative radius
            pointer: {
                length: 0.6, // Relative to gauge radius
                strokeWidth: 0.035, // The thickness
                color: '#ffffff' // Pointer color
            },
            limitMax: false, // If false, max value increases automatically
            limitMin: false, // If true, the min value of the gauge will be fixed
            highDpiSupport: true, // High resolution support
            staticLabels: {
                font: "10px sans-serif",
                labels: [0, 50, 100, 150, 200, 250, 300], // Adjust labels based on max value
                color: "#ffffff",
                fractionDigits: 0
            },
            staticZones: [
                { strokeStyle: "#66BB6A", min: 0, max: 50 },    // Light green
                { strokeStyle: "#43A047", min: 50, max: 100 },  // Medium green
                { strokeStyle: "#2E7D32", min: 100, max: 150 }, // Darker green
                { strokeStyle: "#1B5E20", min: 150, max: 200 }, // Even darker green
                { strokeStyle: "#0D5302", min: 200, max: 300 }  // Darkest green
            ],
            renderTicks: {
                divisions: 10,
                divWidth: 1,
                divColor: '#ffffff',
                subDivisions: 5,
                subDivWidth: 0.5,
                subDivColor: '#ffffff'
            },
            // Customize the gauge background
            backgroundColor: '#1E1E1E',
            renderBackground: true
        };

        let gaugeElement = document.getElementById('speedGauge');
        gauge = new Gauge(gaugeElement).setOptions(options);
        gauge.maxValue = 300; // Set max value based on expected speed
        gauge.setMinValue(0); // Minimum value
        gauge.set(0); // Initialize gauge with 0
    }

    function resetView() {
        $('#resultView').hide();
        $('#startView').show();
        $('#restartBtn').hide();
        $('#speedValue').text('0');
        $('#downloadValue').text('0');
        $('#uploadValue').text('0');
        $('#pingValue').text('0');
        $('#packetLossValue').text('0');
        if (gauge) {
            gauge.set(0);
        }
    }
});
