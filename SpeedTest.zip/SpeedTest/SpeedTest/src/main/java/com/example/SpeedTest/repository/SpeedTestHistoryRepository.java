package com.example.SpeedTest.repository;

import com.example.SpeedTest.model.SpeedTestHistory;
import com.example.SpeedTest.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SpeedTestHistoryRepository extends JpaRepository<SpeedTestHistory, Long> {
    List<SpeedTestHistory> findByUser(User user);
}
