package com.example.SpeedTest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "com.example.SpeedTest")
public class 	SpeedTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpeedTestApplication.class, args);
	}

}
