package com.example.SpeedTest.service;

import com.example.SpeedTest.model.SpeedTestHistory;
import com.example.SpeedTest.model.SpeedTestResult;
import com.example.SpeedTest.model.User;
import com.example.SpeedTest.repository.SpeedTestHistoryRepository;
import com.example.SpeedTest.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.time.LocalDateTime;

@Service
public class SpeedTestService {

    @Autowired
    private SpeedTestHistoryRepository historyRepository;

    @Autowired
    private UserRepository userRepository;

    public SpeedTestResult performSpeedTest() {
        double downloadSpeed = 0;
        double uploadSpeed = 0;
        double ping = 0;
        double packetLoss = 0;

        try {
            // Run the speedtest-cli command and capture the output
            ProcessBuilder pb = new ProcessBuilder("speedtest-cli", "--simple");
            Process process = pb.start();
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;

            // Parse the output from speedtest-cli
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("Download:")) {
                    downloadSpeed = Double.parseDouble(line.split(" ")[1]); // Extract the Mbps value
                } else if (line.startsWith("Upload:")) {
                    uploadSpeed = Double.parseDouble(line.split(" ")[1]); // Extract the Mbps value
                } else if (line.startsWith("Ping:")) {
                    ping = Double.parseDouble(line.split(" ")[1]); // Extract the ms value
                }
            }
            while ((line = reader.readLine()) != null) {
                if (line.contains("packet loss")) {
                    String packetLossStr = line.split(",")[2].trim().split(" ")[0]; // Extract packet loss percentage
                    packetLoss = Double.parseDouble(packetLossStr.replace("%", ""));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return new SpeedTestResult(0, 0, 0,0); // Return a default result in case of an error
        }

        // Save the result in the history for the currently authenticated user
        saveHistory(downloadSpeed, uploadSpeed, ping, packetLoss);

        return new SpeedTestResult(downloadSpeed, uploadSpeed, ping, packetLoss);
    }

    private void saveHistory(double downloadSpeed, double uploadSpeed, double ping, double packetLoss) {
        // Get the currently authenticated user
        User currentUser = getCurrentUser();
        if (currentUser != null) {
            // Create a new SpeedTestHistory entry linked to the current user
            SpeedTestHistory history = new SpeedTestHistory(downloadSpeed, uploadSpeed, ping, packetLoss, LocalDateTime.now(), currentUser);
            historyRepository.save(history);
        } else {
            // Handle the case where no user is authenticated (this should normally not happen)
            System.err.println("No authenticated user found. Speed test history not saved.");
        }
    }

    private User getCurrentUser() {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (principal instanceof UserDetails) {
            String username = ((UserDetails) principal).getUsername();
            // Fetch the user from the database using the username
            return userRepository.findByUsername(username);
        } else {
            return null;
        }

    }

}
