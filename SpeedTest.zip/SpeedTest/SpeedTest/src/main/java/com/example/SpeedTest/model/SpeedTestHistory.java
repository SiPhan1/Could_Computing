package com.example.SpeedTest.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@Entity
public class SpeedTestHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private double downloadSpeed;
    private double uploadSpeed;
    private double ping;
    private double packetLoss;

    private LocalDateTime timestamp;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    public SpeedTestHistory() {
    }

    public SpeedTestHistory(double downloadSpeed, double uploadSpeed, double ping, double packetLoss, LocalDateTime timestamp, User user) {
        this.downloadSpeed = downloadSpeed;
        this.uploadSpeed = uploadSpeed;
        this.ping = ping;
        this.packetLoss = packetLoss;
        this.timestamp = timestamp;
        this.user = user;
    }
}
