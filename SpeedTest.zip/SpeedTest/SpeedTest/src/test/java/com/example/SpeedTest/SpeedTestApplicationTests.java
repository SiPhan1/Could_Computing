package com.example.SpeedTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpeedTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
